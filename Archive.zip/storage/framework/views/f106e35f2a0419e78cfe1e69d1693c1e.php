<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <section class="relative h-[50vh] w-full">
        <!-- Background Image -->
        <img src="<?php echo e($recipe->image); ?>" alt="<?php echo e($recipe->name); ?>"
             class="absolute inset-0 w-full h-full object-cover">
        <div class="absolute inset-0 bg-black/60"></div>

        <!-- Content floated right -->
        <div class="relative z-10 h-full flex items-center justify-end px-8 md:px-16">
            <div class="text-right text-white max-w-md">
                <h1 class="text-4xl md:text-5xl font-bold mb-4"><?php echo e($recipe->name); ?></h1>
                <div class="space-y-2 text-sm md:text-base">
                    <p>⏱ Prep Time: <?php echo e($recipe->prep_time ?? 'N/A'); ?></p>
                    <p>🔥 Cook Time: <?php echo e($recipe->cook_time ?? 'N/A'); ?></p>
                    <p>🍽 Servings: <?php echo e($recipe->servings ?? 'N/A'); ?></p>
                    <p>⭐ Rating: <?php echo e($recipe->rating ?? 'N/A'); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Content Section -->
    <section class="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-12">
        <!-- Main Column -->
        <div class="md:col-span-2 space-y-10">
            <!-- Ingredients -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Ingredients</h2>
                <ul class="space-y-2">
                    <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" class="form-checkbox">
                                <span><?php echo e($ingredient); ?></span>
                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- Instructions -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Instructions</h2>
                <ol class="space-y-6 list-decimal list-inside">
                    <?php $__currentLoopData = $recipe->instructions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($step); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        </div>

        <!-- Sidebar -->
        <aside class="space-y-6">
            <div class="bg-white shadow-md rounded-xl p-6">
                <h3 class="text-xl font-semibold mb-2">Details</h3>
                <p><strong>Prep Time:</strong> <?php echo e($recipe->prep_time ?? 'N/A'); ?></p>
                <p><strong>Cook Time:</strong> <?php echo e($recipe->cook_time ?? 'N/A'); ?></p>
                <p><strong>Servings:</strong> <?php echo e($recipe->servings ?? 'N/A'); ?></p>
                <p><strong>Rating:</strong> ⭐ <?php echo e($recipe->rating ?? 'N/A'); ?></p>
            </div>

            <?php if(isset($relatedRecipes)): ?>
                <div>
                    <h3 class="text-xl font-semibold mb-4">Related Recipes</h3>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $relatedRecipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('recipes.show', $related->id)); ?>" class="block">
                                <div class="flex items-center gap-4">
                                    <img src="<?php echo e($related->image); ?>" alt="<?php echo e($related->name); ?>"
                                         class="w-16 h-16 object-cover rounded-lg">
                                    <span class="font-medium"><?php echo e($related->name); ?></span>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </aside>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gpd/Sites/myrecipebook/resources/views/recipes/show.blade.php ENDPATH**/ ?>