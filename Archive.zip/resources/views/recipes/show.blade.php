@extends('layouts.app')

@section('content')
    <!-- Hero Section -->
    <section class="relative h-[50vh] w-full">
        <!-- Background Image -->
        <img src="{{ $recipe->image }}" alt="{{ $recipe->name }}"
             class="absolute inset-0 w-full h-full object-cover">
        <div class="absolute inset-0 bg-black/60"></div>

        <!-- Content floated right -->
        <div class="relative z-10 h-full flex items-center justify-end px-8 md:px-16">
            <div class="text-right text-white max-w-md">
                <h1 class="text-4xl md:text-5xl font-bold mb-4">{{ $recipe->name }}</h1>
                <div class="space-y-2 text-sm md:text-base">
                    <p>⏱ Prep Time: {{ $recipe->prep_time ?? 'N/A' }}</p>
                    <p>🔥 Cook Time: {{ $recipe->cook_time ?? 'N/A' }}</p>
                    <p>🍽 Servings: {{ $recipe->servings ?? 'N/A' }}</p>
                    <p>⭐ Rating: {{ $recipe->rating ?? 'N/A' }}</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Content Section -->
    <section class="max-w-7xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-12">
        <!-- Main Column -->
        <div class="md:col-span-2 space-y-10">
            <!-- Ingredients -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Ingredients</h2>
                <ul class="space-y-2">
                    @foreach($recipe->ingredients as $ingredient)
                        <li>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" class="form-checkbox">
                                <span>{{ $ingredient }}</span>
                            </label>
                        </li>
                    @endforeach
                </ul>
            </div>

            <!-- Instructions -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Instructions</h2>
                <ol class="space-y-6 list-decimal list-inside">
                    @foreach($recipe->instructions as $step)
                        <li>{{ $step }}</li>
                    @endforeach
                </ol>
            </div>
        </div>

        <!-- Sidebar -->
        <aside class="space-y-6">
            <div class="bg-white shadow-md rounded-xl p-6">
                <h3 class="text-xl font-semibold mb-2">Details</h3>
                <p><strong>Prep Time:</strong> {{ $recipe->prep_time ?? 'N/A' }}</p>
                <p><strong>Cook Time:</strong> {{ $recipe->cook_time ?? 'N/A' }}</p>
                <p><strong>Servings:</strong> {{ $recipe->servings ?? 'N/A' }}</p>
                <p><strong>Rating:</strong> ⭐ {{ $recipe->rating ?? 'N/A' }}</p>
            </div>

            @if(isset($relatedRecipes))
                <div>
                    <h3 class="text-xl font-semibold mb-4">Related Recipes</h3>
                    <div class="space-y-4">
                        @foreach($relatedRecipes as $related)
                            <a href="{{ route('recipes.show', $related->id) }}" class="block">
                                <div class="flex items-center gap-4">
                                    <img src="{{ $related->image }}" alt="{{ $related->name }}"
                                         class="w-16 h-16 object-cover rounded-lg">
                                    <span class="font-medium">{{ $related->name }}</span>
                                </div>
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif
        </aside>
    </section>
@endsection
