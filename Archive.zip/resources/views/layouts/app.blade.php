<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'Laravel Recipe App') }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <script src="//unpkg.com/alpinejs" defer></script>
</head>
<body class="bg-gray-50 text-gray-900" x-data="{ mobileOpen: false }">

    <!-- Transparent Hero Nav -->
    <header class="absolute top-0 w-full z-50 transition-transform duration-500 ease-ease">
        <div class="w-full mx-auto px-6 flex justify-between items-center py-4">
            <!-- Logo -->
            <a href="{{ route('home') }}" class="flex items-center gap-2">
                <svg class="w-8 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 123.65 268.08">
                    <g>
                        <polygon points="94.42 90.69 85.61 87.47 11.91 257.88 39.82 268.08 94.42 90.69" style="fill:#dc2626;"/>
                        <ellipse cx="100.26" cy="59.46" rx="41.53" ry="19.74"
                                 transform="translate(9.99 133.22) rotate(-69.92)" style="fill:#dc2626;"/>
                    </g>
                    <g>
                        <polygon points="48.6 86.65 39.76 89.78 91.53 268.08 119.54 258.17 48.6 86.65" style="fill:#dc2626;"/>
                        <ellipse cx="33.21" cy="58.86" rx="19.74" ry="41.53"
                                 transform="translate(-17.74 14.46) rotate(-19.5)" style="fill:#dc2626;"/>
                    </g>
                </svg>
                <span class="text-2xl font-bold text-red-600">Dishly</span>
            </a>

            <!-- Links -->
            <nav class="hidden md:flex space-x-6">
                <a href="{{ route('home') }}" class="text-gray-700 hover:text-red-600">Home</a>
                <a href="{{ route('recipes.index') }}" class="text-gray-700 hover:text-red-600">Recipes</a>
                <a href="#" class="text-gray-700 hover:text-red-600">About</a>
                <a href="#" class="text-gray-700 hover:text-red-600">Contact</a>
            </nav>

            <!-- Auth -->
            <div class="hidden md:flex items-center gap-4">
                <a href="{{ route('login') }}" class="text-gray-700">Login</a>
                <a href="{{ route('register') }}" class="bg-green-600 text-white px-4 py-2 rounded-lg">Sign Up</a>
            </div>

            <!-- Hamburger -->
            <button @click="mobileOpen = true" class="md:hidden text-gray-800 focus:outline-none">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                     stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>
    </header>

    <!-- Sticky Green Nav -->
    <header 
        x-data="{ scrolled: false }" 
        x-init="window.addEventListener('scroll', () => { scrolled = window.scrollY > 80 })"
        class="fixed top-0 left-0 w-full z-40 transition-transform duration-500 ease-ease">

        <div 
            :class="scrolled ? 'translate-y-0 bg-green-700 shadow-md' : '-translate-y-full'"
            class="green transition-transform duration-500 w-full">
            
            <div class="w-full mx-auto px-6 flex justify-between items-center py-4">
                <!-- Logo -->
                <a href="{{ route('home') }}" class="flex items-center gap-2">
                    <svg class="w-8 h-8" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 123.65 268.08">
                        <g>
                            <polygon points="94.42 90.69 85.61 87.47 11.91 257.88 39.82 268.08 94.42 90.69" style="fill:#ffffff;"/>
                            <ellipse cx="100.26" cy="59.46" rx="41.53" ry="19.74"
                                     transform="translate(9.99 133.22) rotate(-69.92)" style="fill:#ffffff;"/>
                        </g>
                        <g>
                            <polygon points="48.6 86.65 39.76 89.78 91.53 268.08 119.54 258.17 48.6 86.65" style="fill:#ffffff;"/>
                            <ellipse cx="33.21" cy="58.86" rx="19.74" ry="41.53"
                                     transform="translate(-17.74 14.46) rotate(-19.5)" style="fill:#ffffff;"/>
                        </g>
                    </svg>
                    <span class="text-2xl font-bold text-white">Dishly</span>
                </a>

                <!-- Links -->
                <nav class="hidden md:flex space-x-6">
                    <a href="{{ route('home') }}" class="text-white hover:text-gray-200">Home</a>
                    <a href="{{ route('recipes.index') }}" class="text-white hover:text-gray-200">Recipes</a>
                    <a href="#" class="text-white hover:text-gray-200">About</a>
                    <a href="#" class="text-white hover:text-gray-200">Contact</a>
                </nav>

                <!-- Auth -->
                <div class="hidden md:flex items-center gap-4">
                    <a href="/admin/login" class="text-white">Login</a>
                    <a href="{{ route('register') }}" class="bg-green-600 text-white px-4 py-2 rounded-lg">Sign Up</a>
                </div>

                <!-- Hamburger -->
                <button @click="mobileOpen = true" class="md:hidden text-white focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                         stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M4 6h16M4 12h16M4 18h16"/>
                    </svg>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Sidebar (Shared for both navs) -->
    <div x-show="mobileOpen" class="fixed inset-0 z-50 flex">
        <!-- Backdrop -->
        <div @click="mobileOpen = false"
             class="fixed inset-0 bg-black bg-opacity-50 transition-opacity"></div>

        <!-- Sidebar -->
        <div x-show="mobileOpen"
             x-transition:enter="transform transition ease-in-out duration-300"
             x-transition:enter-start="-translate-x-full"
             x-transition:enter-end="translate-x-0"
             x-transition:leave="transform transition ease-in-out duration-300"
             x-transition:leave-start="translate-x-0"
             x-transition:leave-end="-translate-x-full"
             class="relative bg-green-700 text-white w-64 p-6 space-y-4">
            <button @click="mobileOpen = false" class="absolute top-4 right-4 text-white">
                ✕
            </button>
            <a href="{{ route('home') }}" class="block hover:text-gray-200">Home</a>
            <a href="{{ route('recipes.index') }}" class="block hover:text-gray-200">Recipes</a>
            <a href="#" class="block hover:text-gray-200">About</a>
            <a href="#" class="block hover:text-gray-200">Contact</a>
            <a href="/admin/login" class="block hover:text-gray-200">Login</a>
            <a href="{{ route('register') }}" class="block bg-green-600 text-white px-4 py-2 rounded-lg text-center">Sign Up</a>
        </div>
    </div>

    <!-- Page Content -->
    <main>
        @yield('content')
    </main>
</body>
</html>
