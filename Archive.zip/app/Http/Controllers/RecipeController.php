<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Recipe;
use Illuminate\Support\Facades\Auth;

class RecipeController extends Controller
{
    // show all recipes
    public function index() 
    {
        $recipes = Recipe::latest()->paginate(10);
        return view('recipes.index', compact('recipes'));
    }
    // show 1 recipe
    public function show(Recipe $recipe) 
    {
        $recipe->ingredients = explode(',', $recipe->ingredients);
        $recipe->instructions = explode("\n", $recipe->instructions);
        $relatedRecipes = Recipe::where('id', '!=', $recipe->id)
        ->inRandomOrder()
        ->take(3)
        ->get();

        return view('recipes.show', compact('recipe', 'relatedRecipes'));        
    }
    // only show form for logged in users
    public function create()
    {
        return view('recipes.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max255',
            'description' => 'nullable|string',
            'ingredients' => 'nullable|string',
            'instructions' => 'nullable|string',
            'image' => 'nullable|image|max2048', // file upload
            'description' => 'nullable|string',
        ]);

        $path = null;
        if($request->hasFile('image')) {
            $path = $request->file('image')->store('recipes', 'public');
        }

        $recipe = Recipe::create([
            'title' => $validated['title'],
            'description' => $validated['description'],
            'ingredients' => $validated['ingredients'],
            'instructions' => $validated['instructions'],
            'image_url' => $path ? \asset('storage/'.$path) : null,
            'user_id' => Auth::id(),
        ]);

        return redirect()->route('recipes.show', $recipe)
        ->with('success', 'Recipes added successfully!');
    }
}
