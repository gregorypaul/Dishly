<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use App\Models\Recipe;
use App\Models\User;

class ImportRecipes extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'recipes:import {--count=5}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import recipes from TheMealDB API';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $count = (int) $this->option('count');
        $this->info("Fetching {$count} recipes from TheMealDB");
        
        $response = HTTP::GET('https://www.themealdb.com/api/json/v1/1/search.php?s=');

        if($response->failed()) {
            $this->error('API request failed');
        }

        $meals = $response->json()['meals'] ?? [];
        if(!$meals) {
            $this->error('No recipes found.');
        }

        $user = User::first();
        if(!$user) {
            $this->error('No users found.');
            return;
        }

        foreach(array_slice($meals, 0, $count) as $meal) {
            $this->info("Meal: {$meal['strMeal']}");
            $this->info("Image: " . ($meal['strMealThumb'] ?? 'NO IMAGE'));
            Recipe::updateOrCreate(
                ['title' => $meal['strMeal']],
                [
                    'description' => $meal['strArea'] ?? 'unknown',
                    'ingredients' => implode(', ', array_filter([
                        $meal['strIngredient1'] ?? null,
                        $meal['strIngredient2'] ?? null,
                        $meal['strIngredient3'] ?? null,
                        $meal['strIngredient4'] ?? null,
                    ])),
                    'instructions' => $meal['strInstructions'] ?? null,
                    'image_url' => $meal['strMealThumb'] ?? null,
                    'user_id' => $user->id,
                ],
            );
        }
        $this->info('Recipes imported successfully');
    }
}